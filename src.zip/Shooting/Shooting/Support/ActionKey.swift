//
//  ActionKey.swift
//  Shooting
//
//  Created by tongji on 2020/12/25.
//  Copyright © 2020 rio. All rights reserved.
//

import Foundation

enum ActionKey: String{
    case reloading
    
    var key: String{
        return rawValue
    }
}
