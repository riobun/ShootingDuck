//
//  Target.swift
//  Shooting
//
//  Created by rio on 2020/12/24.
//  Copyright © 2020 rio. All rights reserved.
//

import Foundation
import SpriteKit

class Target: SKNode {
    
}
